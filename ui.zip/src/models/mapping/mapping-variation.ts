export interface MappingVariation {
  entity_id: string;
  name: string;
  provider_id: number;
}
