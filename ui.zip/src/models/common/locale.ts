import { LocaleType } from "./locale-type";

export interface Locale {
  locale: Map<string, LocaleType>;
}
