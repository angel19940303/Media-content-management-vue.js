export interface CountryCode {
  name: string;
  alpha_2_code: string;
  alpha_3_code: string;
  numeric: number;
}
