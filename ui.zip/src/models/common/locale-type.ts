export interface LocaleType {
  value: string;
  manual: number;
}
