export interface NewsTag {
  ID: string | undefined;
  Meta: string;
}
