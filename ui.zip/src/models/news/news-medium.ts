export interface NewsMedium {
  ID: string | undefined;
  URL: string;
  Type: string;
}
