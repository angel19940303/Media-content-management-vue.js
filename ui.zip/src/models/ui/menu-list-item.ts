export interface MenuListItem {
  id: string;
  sport: number;
  name?: string;
}
