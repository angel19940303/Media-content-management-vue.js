export interface EditStatusMessage {
  message: string;
  detail?: string;
  type: number;
  skipBottomBar?: boolean;
}
