export interface MappingFilter {
  sourceProviderId?: number;
  targetProviderId?: number;
  stageName?: string;
  teamName?: string;
}
