export interface LocEnumDataPayload {
  id: number | undefined;
  sportId: number;
  name?: string;
  items: any;
}
