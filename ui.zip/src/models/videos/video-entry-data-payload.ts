export interface VideoEntryDataPayload {
  id: string | undefined;
  url: string;
  type: number;
  date: string;
}
