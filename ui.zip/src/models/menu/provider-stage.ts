export interface ProviderStage {
  c_id?: string;
  c_name?: string;
  end?: number;
  pid?: number;
  s_id: number;
  season?: string;
  st_gender?: number;
  st_id?: string;
  st_name?: string;
  start?: number;
}
