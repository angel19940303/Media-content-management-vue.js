export interface MenuItemPayloadBuilderDefaultValues {
  startDate: Date;
  start: number;
  endDate: Date;
  end: number;
  seasonName: string;
  language: string;
  flagBaseUrl: string;
}
