export interface MenuDataPayload {
  id: number | undefined;
  sportId: number;
  menu: any;
  name?: string;
  publishUrl?: string;
}
