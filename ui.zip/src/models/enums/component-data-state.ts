export class ComponentDataState {
  static readonly INITIALIZING = 0;
  static readonly READY = 1;
  static readonly ERROR = 2;
}
